<?php switch($_GET['action']) { ?>
	
	<?php 
		case "submit":
		default: 
	?>

		{
			success: true,
			data: {

			},
			errors: {}
		}

	<?php } ?>

<?php } ?>